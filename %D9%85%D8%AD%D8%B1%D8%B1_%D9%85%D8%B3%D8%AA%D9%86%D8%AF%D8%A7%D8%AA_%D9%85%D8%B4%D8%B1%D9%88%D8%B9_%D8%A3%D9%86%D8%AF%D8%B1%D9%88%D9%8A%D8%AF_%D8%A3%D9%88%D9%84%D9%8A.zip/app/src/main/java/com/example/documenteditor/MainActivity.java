package com.example.documenteditor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout root, list;
    private static final int REQUEST_SCAN = 101;
    private static final int REQUEST_OPEN = 102;
    private Bitmap lastScan;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showHome();
    }

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(dp(8), dp(8), dp(8), dp(8));
        return t;
    }

    private Button button(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private void setup(String title) {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(16));
        root.setBackgroundColor(Color.rgb(246,248,252));
        scroll.addView(root);
        setContentView(scroll);
        TextView heading = text(title, 25, Color.rgb(25,55,100));
        heading.setGravity(Gravity.CENTER);
        root.addView(heading);
    }

    private void showHome() {
        setup("محرر مستندات");
        root.addView(text("مكتبك ومستنداتك في مكان واحد", 15, Color.DKGRAY));
        root.addView(button("＋ إنشاء مستند نصي", this::newNote));
        root.addView(button("▣ مسح ورقة بالكاميرا", this::scan));
        root.addView(button("فتح ملف من الهاتف", this::openFile));
        root.addView(button("عرض المستندات المحفوظة", this::showDocuments));
        root.addView(text("الإصدار الأولي 0.1 • يعمل محليًا دون حساب", 13, Color.GRAY));
    }

    private void newNote() {
        setup("مستند نصي جديد");
        EditText title = new EditText(this);
        title.setHint("عنوان المستند");
        root.addView(title);
        EditText body = new EditText(this);
        body.setHint("اكتب النص هنا...");
        body.setGravity(Gravity.TOP | Gravity.START);
        body.setMinLines(10);
        body.setPadding(dp(12),dp(12),dp(12),dp(12));
        root.addView(body, new LinearLayout.LayoutParams(-1, dp(260)));
        root.addView(button("حفظ المستند", () -> {
            String name = title.getText().toString().trim();
            if (name.isEmpty()) name = "مستند";
            try {
                String safe = name.replaceAll("[^a-zA-Z0-9ء-ي _-]", "_");
                File dir = new File(getFilesDir(), "documents");
                if (!dir.exists()) dir.mkdirs();
                File f = new File(dir, safe + "_" + System.currentTimeMillis() + ".txt");
                try (FileOutputStream out = new FileOutputStream(f)) {
                    out.write(("العنوان: " + name + "\n\n" + body.getText().toString()).getBytes("UTF-8"));
                }
                Toast.makeText(this, "تم حفظ المستند داخل التطبيق", Toast.LENGTH_LONG).show();
                showHome();
            } catch (Exception e) {
                Toast.makeText(this, "تعذر الحفظ: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }));
        root.addView(button("رجوع", this::showHome));
    }

    private void scan() {
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (i.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(i, REQUEST_SCAN);
        } else {
            Toast.makeText(this, "لا يوجد تطبيق كاميرا متاح", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == REQUEST_SCAN) {
            Bundle extras = data.getExtras();
            if (extras != null) {
                Object obj = extras.get("data");
                if (obj instanceof Bitmap) {
                    lastScan = (Bitmap)obj;
                    showScanPreview();
                }
            }
        } else if (requestCode == REQUEST_OPEN && data.getData() != null) {
            readPickedFile(data.getData());
        }
    }

    private void showScanPreview() {
        setup("معاينة المسح");
        root.addView(text("تم التقاط صورة معاينة. بعض تطبيقات الكاميرا تعيد صورة صغيرة؛ للحصول على مسح عالي الجودة سنضيف حفظ الصورة الكاملة في مرحلة لاحقة.", 15, Color.DKGRAY));
        root.addView(button("حفظ كملف PDF", this::saveScanPdf));
        root.addView(button("إعادة التصوير", this::scan));
        root.addView(button("الرئيسية", this::showHome));
    }

    private void saveScanPdf() {
        if (lastScan == null) return;
        try {
            PdfDocument pdf = new PdfDocument();
            int w = 595, h = 842;
            PdfDocument.Page page = pdf.startPage(new PdfDocument.PageInfo.Builder(w,h,1).create());
            Canvas canvas = page.getCanvas();
            canvas.drawColor(Color.WHITE);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            float scale = Math.min((w - 32f) / lastScan.getWidth(), (h - 32f) / lastScan.getHeight());
            float dw = lastScan.getWidth() * scale, dh = lastScan.getHeight() * scale;
            canvas.drawBitmap(lastScan, null, new android.graphics.RectF((w-dw)/2, (h-dh)/2, (w+dw)/2, (h+dh)/2), p);
            pdf.finishPage(page);
            String name = "Scan_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".pdf";
            File dir = new File(getFilesDir(), "documents");
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, name);
            try (FileOutputStream out = new FileOutputStream(f)) { pdf.writeTo(out); }
            pdf.close();
            Toast.makeText(this, "تم حفظ PDF داخل التطبيق: " + name, Toast.LENGTH_LONG).show();
            showDocuments();
        } catch (Exception e) {
            Toast.makeText(this, "تعذر إنشاء PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void openFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQUEST_OPEN);
    }

    private void readPickedFile(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            byte[] buf = new byte[4096];
            StringBuilder sb = new StringBuilder();
            int n, total=0;
            while ((n = in.read(buf)) > 0 && total < 500000) {
                sb.append(new String(buf, 0, n, "UTF-8")); total += n;
            }
            setup("محتوى الملف");
            EditText content = new EditText(this);
            content.setText(sb.toString());
            content.setGravity(Gravity.TOP | Gravity.START);
            content.setMinLines(12);
            root.addView(content, new LinearLayout.LayoutParams(-1, dp(350)));
            root.addView(text("ملاحظة: هذه النسخة تعرض النصوص القابلة للقراءة فقط؛ تحرير DOCX وPDF مباشرة قيد التطوير.", 13, Color.GRAY));
            root.addView(button("الرئيسية", this::showHome));
        } catch (Exception e) {
            new AlertDialog.Builder(this).setTitle("تعذر فتح الملف")
                .setMessage("يمكن اختيار ملفات نصية في هذه النسخة الأولية. دعم PDF وDOCX المتقدم سيضاف لاحقًا.")
                .setPositiveButton("حسنًا", (d,w)->showHome()).show();
        }
    }

    private void showDocuments() {
        setup("مستنداتي");
        File dir = new File(getFilesDir(), "documents");
        File[] files = dir.listFiles();
        if (files == null || files.length == 0) {
            root.addView(text("لا توجد مستندات محفوظة بعد.", 16, Color.DKGRAY));
        } else {
            for (File f : files) {
                root.addView(text("📄 " + f.getName() + "\n" + (f.length()/1024) + " KB", 15, Color.DKGRAY));
                root.addView(button("مشاركة الملف", () -> shareFile(f)));
            }
        }
        root.addView(button("الرئيسية", this::showHome));
    }

    private void shareFile(File f) {
        try {
            // Use Android's ACTION_SEND with a file URI only for this prototype.
            // A production build should use FileProvider for secure sharing.
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(f.getName().endsWith(".pdf") ? "application/pdf" : "text/plain");
            i.putExtra(Intent.EXTRA_TEXT, "المستند محفوظ داخل تطبيق محرر مستندات: " + f.getName());
            startActivity(Intent.createChooser(i, "مشاركة المستند"));
        } catch (Exception e) {
            Toast.makeText(this, "تعذرت المشاركة", Toast.LENGTH_SHORT).show();
        }
    }
}
